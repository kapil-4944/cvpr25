function run_strred_opt(ref_filename, dis_filename, width, height)

path(path, './strred');
path(path, './matlabPyrTools');

calcStrredScore_opt(ref_filename, dis_filename, height, width);

end




